# Languages Used
- Homework 1: Haskell
- Homework 2: Python
- Homework 4: Java
